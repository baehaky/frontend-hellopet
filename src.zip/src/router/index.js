import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import LoginView from '@/views/LoginView.vue'
import RegisterView from '@/views/RegisterView.vue'
import JadwalDokter from '@/views/JadwalDokter.vue'
import InformasiHewan from '@/views/InformasiHewan.vue'
import DokterFavorite from '@/views/DokterFavorite.vue'
const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: HomeView,
    },
    {
      path: '/:pathMatch(.*)*',
      name: 'NotFound',
      component: () => import('../views/404NotFound.vue'),
    },
    {
      path: '/login',
      name: 'login',
      component: LoginView,
    },
    {
      path: '/register',
      name: 'register',
      component: RegisterView,
    },
    {
      path: '/jadwaldokter',
      name: 'jadwal-dokter',
      component: JadwalDokter,
    },
    {
      path: '/informasi',
      name: 'informasi-hewan',
      component: InformasiHewan,
    },
    {
      path: '/dokter-favorite',
      name: 'dokter-favorite',
      component: DokterFavorite,
    }
  ],
})

export default router
