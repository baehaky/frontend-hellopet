<template>
  <footer>
    <p class="text-center border-t-[1.5px] p-3 border-b-black">
      © 2023 HellowPet™. All Rights Reserved.
    </p>
  </footer>
</template>
