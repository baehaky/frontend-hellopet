<template>
  <section class="bg-[#16BDCA]">
    <div
      class="grid max-w-screen-xl px-4 py-8 mx-auto md:grid-cols-3 lg:grid-cols-12 gap-8 lg:py-16"
    >
      <div class="mr-auto place-self-center md:col-span-2 lg:col-span-9 ">
        <h1
          class="max-w-full mb-4 text-xl text-justify font-extrabold tracking-tight leading-none md:text-3xl xl:text-4xl dark:text-white"
        >
          Kami Hadir untuk Merawat <span class="text-[#FCFF82]">Kesehatan</span> Hewan
          <span class="text-[#FCFF82]">Kesayangan</span> Anda karena Mereka Lebih dari Sekadar
          Hewan, Mereka adalah Bagian dari <span class="text-[#FCFF82]">Keluarga</span>
        </h1>
      </div>
      <div class="flex justify-center md:col-span-1 lg:col-span-3">
        <img class="h-auto md:w-50 w-28" src="@/assets/images/9.png" alt="" />
      </div>
    </div>
  </section>
</template>
