<template>
  <section class="bg-[#FCFF82] py-12">
    <h1 class="text-[#FF8095] text-center pb-6 text-xl font-bold">Layanan Kami</h1>
    <div class="flex justify-center">
      <div
        class="flex flex-col items-center border border-gray-200 rounded-lg shadow-sm max-w-xs md:max-w-xl bg-[#FF8095] p-5"
      >
        <img
          class="object-cover w-38 rounded-t-lg h-auto md:h-auto md:w-42 md:rounded-none md:rounded-s-lg"
          src="@/assets/images/7.png"
          alt=""
        />
        <div class="flex flex-col justify-between leading-normal">
          <h5 class="text-xl font-bold tracking-tight md:text-left text-center text-white">
            Konsultasi dengan Dokter Hewan
          </h5>
        </div>
      </div>
    </div>
  </section>
</template>
