<template>
  <section class="bg-[#16BDCA] py-20">
    <div class="grid max-w-screen-xl px-4 gap-2 mx-auto lg:gap-8 xl:gap-0 lg:py-16 lg:grid-cols-12">
      <div
        class="mx-auto lg:mr-auto  lg:place-self-center lg:col-span-7"
      >
        <h1
          class="max-w-2xl mb-4 text-xl md:text-5xl text-center font-extrabold tracking-tight leading-none md:text-center dark:text-white"
        >
          Pastikan <span class="text-[#FCFF82]">Kesehatan</span> Hewan Kesayangan Anda Tetap Terjaga
          dengan <span class="text-[#FCFF82]">Perlindungan</span> dari Berbagai
          <span class="text-[#FCFF82]">Penyakit</span>
        </h1>
      </div>
      <div
        class="items-center justify-center lg:mt-0 lg:col-span-5 flex"
      >
        <img src="@/assets/images/output-onlinegiftools.gif" class="w-[60%] md:w-[60%] lg:w-[85%] h-auto" alt="" />
      </div>
    </div>
  </section>
</template>
