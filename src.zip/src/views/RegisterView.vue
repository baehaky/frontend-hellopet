<script setup>
import { RouterLink } from 'vue-router'

import { reactive } from 'vue'

const form = reactive({
  username: '',
  phone: '',
  address: '',
  gender: '',
  email: '',
  password: '',
})

const formFields = [
  { name: 'username', type: 'text', placeholder: 'Username', col: 'md:w-1/2' },
  { name: 'phone', type: 'text', placeholder: 'Nomor Handphone', col: 'md:w-1/2' },
  { name: 'address', type: 'text', placeholder: 'Alamat', col: 'w-full' },
  {
    name: 'gender',
    type: 'radio',
    label: 'Pilih gender anda',
    options: [
      { label: 'Pria', value: 'pria' },
      { label: 'Wanita', value: 'wanita' },
    ],
  },
  { name: 'email', type: 'email', placeholder: 'Email', col: 'w-full' },
  { name: 'password', type: 'password', placeholder: 'Password', col: 'w-full' },
]

const submitForm = () => {
  console.log('Data form:', form)
  // Lanjutkan ke API atau validasi
}
</script>

<template>
  <section className="min-h-screen flex items-stretch flex-row-reverse">
    <div className="lg:flex w-1/2 hidden bg-teal-400  items-center">
      <div className="w-full px-2 text-white">
        <h1 className="text-5xl font-bold text-left tracking-wide">Daftarkan segera akun kamu</h1>
        <RouterLink to="/">
          <button
            className="group relative mt-5 h-12 w-48 overflow-hidden rounded-lg bg-white text-lg shadow"
          >
            <div
              className="absolute inset-0 w-3 bg-amber-400 transition-all duration-[250ms] ease-out group-hover:w-full"
            ></div>
            <span className="relative text-teal-600 group-hover:text-white"> Kembali </span>
          </button>
        </RouterLink>
      </div>
    </div>
    <div className="lg:w-2/3 w-full flex items-center justify-center text-center md:px-16 px-0">
      <div className="w-full py-6 ">
        <h1 className="my-6 text-black text-3xl font-bold">Daftarkan Akun Kamu</h1>
        <div>
          <form className="sm:w-2/3 w-full px-4 lg:px-0 mx-auto flex flex-wrap">
            <div v-for="field in formFields" :key="field.name">
              <div v-if="field.type === 'radio'" class="pb-2 pt-3 w-full">
                <label class="block text-left">{{ field.label }}</label>
                <div class="flex justify-around mt-4">
                  <div
                    class="flex items-center"
                    v-for="option in field.options"
                    :key="option.value"
                  >
                    <input
                      v-model="form.gender"
                      :value="option.value"
                      type="radio"
                      :name="field.name"
                      class="w-4 h-4"
                    />
                    <label class="ms-2 text-sm font-medium">{{ option.label }}</label>
                  </div>
                </div>
              </div>

              <div v-else :class="`pb-2 pt-4 w-full ${field.col || ''}`">
                <input
                  v-model="form[field.name]"
                  :type="field.type"
                  :placeholder="field.placeholder"
                  class="block w-full p-4 text-lg rounded-sm border-2"
                />
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </section>
</template>
