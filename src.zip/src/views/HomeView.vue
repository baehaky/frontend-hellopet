<script setup>
import EndSectionHome from '@/components/homePage/EndSectionHome.vue'
import HeroSection from '@/components/homePage/HeroSection.vue'
import OurServiceSection from '@/components/homePage/OurServiceSection.vue'
</script>

<template>
  <HeroSection />
  <OurServiceSection />
  <EndSectionHome />
</template>
